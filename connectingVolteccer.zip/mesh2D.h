//==================================================================================
// 
// ���b�V��2D�N���X�̃w�b�_�[�t�@�C�� [mesh2D.h]
// Author : TENMA SAITO
// Date   : 2026/5/30
// 
//==================================================================================
#ifndef _MESH2D_H_
#define _MESH2D_H_

//**********************************************************************************
// *** �C���N���[�h�t�@�C�� ***
//**********************************************************************************
#include "mesh.h"

//**********************************************************************************
// *** �}�N����` ***
//**********************************************************************************

//**********************************************************************************
// *** ���b�V��2D�N���X ***
//**********************************************************************************
class CMesh2D : public CMesh
{
public:
	static CMesh2D *Create(const int nNumVtx, const int nNumIdx, const int nNumPrim);

	CMesh2D();
	~CMesh2D();

	HRESULT Init(const int nNumVtx, const int nNumIdx, const int nNumPrim, const size_t vtxSize, const DWORD nFlags) override;
	void Uninit(void) override;
	void Update(void) override;
	void Draw(void) override;

private:
};
#endif