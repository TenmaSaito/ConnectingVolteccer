//==================================================================================
// 
// �p�[�e�B�N��(�N�H�[�^�j�I���d�l)�̐����N���X�̃w�b�_�[�t�@�C�� [particleQuaternionBuilder.h]
// Author : TENMA SAITO
// Date   : 2026/8/27
// 
//==================================================================================
#ifndef _PARTICLE_QUATERNION_BUILDER_H_		// �C���N���[�h�K�[�h
#define _PARTICLE_QUATERNION_BUILDER_H_

//**********************************************************************************
// *** �C���N���[�h�t�@�C�� ***
//**********************************************************************************
#include "particleQuaternion.h"

//**********************************************************************************
// *** �p�[�e�B�N��(�N�H�[�^�j�I���d�l)�����N���X ***
//**********************************************************************************
class CParticleQuaternionBuilder
{
public:
	CParticleQuaternionBuilder();
	~CParticleQuaternionBuilder();

	CParticleQuaternionBuilder &SetPosition(const Vector3 &pos);
	CParticleQuaternionBuilder &SetVecQua(const Vector3 &vecQua);
	CParticleQuaternionBuilder &SetAngle(const float fAngle);
	CParticleQuaternionBuilder &SetMove(const Vector3 &move);
	CParticleQuaternionBuilder &SetScale(const Vector2 &scale);
	CParticleQuaternionBuilder &SetColor(const Color &color);
	CParticleQuaternionBuilder &SetNumEffectFrame(const int nNumEffectFrame);
	CParticleQuaternionBuilder &SetLife(const int nLife);
	CParticleQuaternionBuilder &SetPositionVariation(const Vector3 &posVariation);
	CParticleQuaternionBuilder &SetMoveVariation(const Vector3 &moveVariation);
	CParticleQuaternionBuilder &SetScaleVariation(const Vector2 &scaleVariation);
	CParticleQuaternionBuilder &SetNumEffectVariation(const int nNumEffectVariation);
	CParticleQuaternionBuilder &SetPercent(const int nPercent);
	CParticleQuaternionBuilder &SetEffectLifeMax(const int nEffectLifeMax);
	CParticleQuaternionBuilder &SetEnableAlphaBlending(const bool bEnable);
	CParticleQuaternion *Build(void) const { return CParticleQuaternion::Create(m_setting); }

private:
	CParticleQuaternion::Setting m_setting;		// �p�[�e�B�N���������̐ݒ�
};
#endif