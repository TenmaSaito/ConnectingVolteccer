//==================================================================================
// 
// �I�u�W�F�N�g���C���N���X�̃w�b�_�[�t�@�C�� [objectLine.h]
// Author : TENMA SAITO
// Date   : 2026/7/27
// 
//==================================================================================
#ifndef _OBJECTLINE_H_		// �C���N���[�h�K�[�h
#define _OBJECTLINE_H_

//**********************************************************************************
// *** �C���N���[�h�t�@�C�� ***
//**********************************************************************************
#include "object.h"

//**********************************************************************************
// *** �}�N����` ***
//**********************************************************************************

//**********************************************************************************
// *** �I�u�W�F�N�g���C���N���X ***
//**********************************************************************************
class CObjectLine : public CObject
{
public:
	CObjectLine(const int nPriority = DEFAULT_OBJ_PRIORITY);
	~CObjectLine();

	static CObjectLine *Create(const Vector3 &start, const Vector3 &end);
	static CObjectLine *Create(const Vector3 &origin, const Vector3 &vec, const float fLength);

	HRESULT Init(const Vector3 &p1, const Vector3 &p2);
	HRESULT Init(const Vector3 &origin, const Vector3 &vec, const float fLength);
	void Uninit(void);
	void Update(void);
	void Draw(void);
	void SetPoint(const Vector3 &start, const Vector3 &end);
	const Vector3 *GetStart(void) const { return &m_start; }
	const Vector3 *GetEnd(void) const { return &m_end; }
	void SetVector(const Vector3 &origin, const Vector3 &vec, const float fLength);
	const Vector3 *GetOrigin(void) const { return &m_start; }
	const Vector3 *GetVector(void) const { return &m_vec; }
	float GetLength(void) const { return m_fLength; }
	void SetDisp(const bool bDisp) { m_bDisp = bDisp; }
	bool GetDisp(void) const { return m_bDisp; }
	void SetLife(const int nLife) { m_nLife = nLife; }
	int GetLife(void) const { return m_nLife; }

private:
	HRESULT CreateVertex(void);
	void UpdateVertex(void);

	LPDIRECT3DVERTEXBUFFER9 m_pVtxBuff;		// ���_�o�b�t�@
	Vector3 m_start, m_end;			// �n�_�A�I�_
	Vector3 m_vec;			// �n�_�ƕ����x�N�g��
	float m_fLength;		// �x�N�g���̒���
	Color m_color;			// �F
	int m_nLife;			// ����
	bool m_bDisp;			// �`�悷�邩
};
#endif
