//==================================================================================
// 
// �f���N���X�̃w�b�_�[�t�@�C�� [planet.h]
// Author : TENMA SAITO
// Date   : 2026/6/23
// 
//==================================================================================
#ifndef _PLANET_H_
#define _PLANET_H_

//**********************************************************************************
// *** �C���N���[�h�t�@�C�� ***
//**********************************************************************************
#include "object.h"

//**********************************************************************************
// *** �}�N����` ***
//**********************************************************************************
#define PLANET_HEIGHT		(1115.0f)		// �f���̔��a
#define PLANET_PRIORITY		DEFAULT_OBJ_PRIORITY		// �f���̗D�揇��

//**********************************************************************************
// *** �O���錾 ***
//**********************************************************************************
class CLasso;

//**********************************************************************************
// *** �f���N���X ***
//**********************************************************************************
class CPlanet : public CObject
{
public:
	static CPlanet *Create(void);

	CPlanet();
	~CPlanet();

	HRESULT Init(void);
	void Uninit(void);
	void Update(void);
	void Draw(void);
	void Move(const Vector3 &rot, const float fLength);
	float GetAngle(void) const { return m_fAngle; }
	const Vector3 *GetVecQua(void) const { return &m_vecQua; }
	const Matrix *GetMatrix(void) const { return &m_mtxWorld; }
	void MultiplyQuaternion(const Quaternion &quaMultiply) { m_qua = m_qua * quaMultiply; }
	const Quaternion *GetQuaternion(void) const { return &m_qua; }
	const Vector3 *GetPosition(void) const { return &m_pos; }
	Vector3 GetVtxMax(void) const;

private:
	Vector3 m_pos;			// �f���̈ʒu
	Vector3 m_vecQua;		// �C�ӎ�
	float m_fAngle;			// ��]�p�x
	Quaternion m_qua;		// �f���̃N�H�[�^�j�I��
	Matrix m_mtxWorld;		// ���[���h�}�g���b�N�X
	int m_nIdxModel;		// ���f���C���f�b�N�X
};
#endif