//==================================================================================
// 
// Vector3�̌v�Z�֘A�֐����܂Ƃ߂��w�b�_�[�t�@�C�� [vec3math.h]
// Author : TENMA SAITO
// Date   : 2026/5/16
// 
//==================================================================================
#ifndef _VEC3MATH_H_
#define _VEC3MATH_H_

//**********************************************************************************
// *** �C���N���[�h�t�@�C�� ***
//**********************************************************************************
#include "main.h"

//**********************************************************************************
// *** Vector3�v�Z�֘A���O��� ***
//**********************************************************************************
namespace Vec3
{
	//******************************************************************************
	// *** 3���� ***
	//******************************************************************************
	enum class Axis : char
	{
		X,		// X��
		Y,		// Y��
		Z,		// Z��
		MAX
	};

	// �͈̓`�F�b�N�p
	template<Axis axis>
	concept IsTrueAxis = (axis != Axis::MAX);

	// �ϐ���
	template<Axis axis>
	inline constexpr bool IsTrueAxis_v = IsTrueAxis<axis>;

	// �t���O�Ǘ�
	using AxisFlags = std::array<bool, static_cast<std::size_t>(Axis::MAX)>;

	// �萔
	inline static const Vector3 Zero = VECTOR3_NULL;	// VECTOR3_NULL
	inline static const Vector3 One = VECTOR3_ONE;		// VECTOR3_ONE

	//******************************************************************************
	// *** ���� (�������L��) ***
	//******************************************************************************
	enum class AxisEx : char
	{
		X = static_cast<char>(Axis::X),		// X��
		Y = static_cast<char>(Axis::Y),		// Y��
		Z = static_cast<char>(Axis::Z),		// Z��
		XY,		// X + Y��
		XZ,		// X + Z��
		YZ,		// Y + Z��
		XYZ,	// XYZ��
		MAX
	};

	// �͈̓`�F�b�N�p
	template<AxisEx axisEx>
	concept IsTrueAxisEx = (axisEx != AxisEx::MAX);

	// �ϐ���
	template<AxisEx axisEx>
	inline constexpr bool IsTrueAxisEx_v = IsTrueAxisEx<axisEx>;

	// �t���O�Ǘ�
	using AxisExFlags = std::array<bool, static_cast<std::size_t>(AxisEx::MAX)>;

	//******************************************************************************
	// *** �v���g�^�C�v�錾 ***
	//******************************************************************************
	float Length(const Vector3 &vec);
	float Length(const Vector3 &To, const Vector3 &From);
	float LengthSq(const Vector3 &vec);
	float LengthSq(const Vector3 &To, const Vector3 &From);
	float L2Norm(const Vector3 &vec);
	float Dot(const Vector3 &vec1, const Vector3 &vec2);
	bool IsVertical(const Vector3 &vec1, const Vector3 &vec2);
	bool IsParallel(const Vector3 &vec1, const Vector3 &vec2);
	bool IsInsideTriangle(const Vector3 &pos, const Vector3 *pVtx, const bool bInverse = false);
	bool IsInsideViewOfBeside(const Vector3 &pos, const Vector3 &posV, const Vector3 &posR, const float fovy);
	bool IsInsideViewOfVertical(const Vector3 &pos, const Vector3 &posV, const Vector3 &posR, const float fovy);
	float DistancePointToSegment(const Vector3 &point, const Vector3 &segStart, const Vector3 &segEnd);
	float Height(const Vector3 &pos, const Vector3 &vtx, const Vector3 &nor);
	Vector3 Nor(const Vector3 &origin, const Vector3 *pVtx, const bool bInverse = false);
	Vector3 Cross(const Vector3 &vec1, const Vector3 &vec2);
	Vector3 Normalize(const Vector3 &vec);
	Vector3 Lerp(const Vector3 &start, const Vector3 &end, const float t);
	Vector3 Middle(const Vector3 &p1, const Vector3 &p2);
	Vector3 Direction(const Vector3 &To, const Vector3 &From);
	Vector3 Direction(const Vector3 &angle);
	Vector3 Random(void);
	Vector3 Random(const Vector3 &min, const Vector3 &max);
	Vector3 Clamp(const Vector3 &vec, const Vector3 &min, const Vector3 &max);
	Vector3 FixedRotation(const Vector3 &rot);
	Vector3 Arc(const float fRadius, const float fTheta, const float fPhi, const Vector3 &offset = VECTOR3_NULL);
	Vector3 &Fill(Vector3 &rVec, const float fValue);
	Vector3 Fill(const float fValue);
	Vector3 ToRadian(const Vector3 &degree, const bool bFixed = false);
	Vector3 ToDegree(const Vector3 &radian, const bool bFixed = false);
	Vector2 ToVector2(const Vector3 &vec, const Axis less = Axis::Z);
	void AssignAxis(Vector3 &vec, const Axis axis, const float fValue);
	float GetAxis(Vector3 &vec, const Axis axis);
	AxisEx ToAxisEx(const Axis axis);
	Axis ToAxis(const AxisEx axisEx);
	AxisFlags IsAxis(const Vector3 &vec, const float fEpsilon = FLT_EPSILON);
	AxisExFlags IsAxisEx(const Vector3 &vec, const float fEpsilon = FLT_EPSILON);
}
#endif