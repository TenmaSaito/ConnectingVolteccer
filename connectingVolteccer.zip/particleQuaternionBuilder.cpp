//==================================================================================
// 
// �p�[�e�B�N��(�N�H�[�^�j�I���d�l)�̐����N���X�̃\�[�X�t�@�C�� [particleQuaternionBuilder.cpp]
// Author : TENMA SAITO
// Date   : 2026/8/27
// 
//==================================================================================
//**********************************************************************************
// *** �C���N���[�h�t�@�C�� ***
//**********************************************************************************
#include "particleQuaternionBuilder.h"

//==================================================================================
// --- �R���X�g���N�^ ---
//==================================================================================
CParticleQuaternionBuilder::CParticleQuaternionBuilder()
{ // �����o�ϐ��̃N���A
	ZeroMemory(&m_setting, sizeof(m_setting));
}

//==================================================================================
// --- �f�X�g���N�^ ---
//==================================================================================
CParticleQuaternionBuilder::~CParticleQuaternionBuilder()
{
}

//==================================================================================
// --- �ʒu�̐ݒ� ---
//==================================================================================
CParticleQuaternionBuilder &CParticleQuaternionBuilder::SetPosition(const Vector3 &pos)
{
	m_setting.pos = pos;
	return *this;
}

//==================================================================================
// --- �C�ӎ��̐ݒ� ---
//==================================================================================
CParticleQuaternionBuilder &CParticleQuaternionBuilder::SetVecQua(const Vector3 &vecQua)
{
	m_setting.vecQua = vecQua;
	return *this;
}

//==================================================================================
// --- ��]�x���̐ݒ� ---
//==================================================================================
CParticleQuaternionBuilder &CParticleQuaternionBuilder::SetAngle(const float fAngle)
{
	m_setting.fAngle = fAngle;
	return *this;
}

//==================================================================================
// --- �ړ��ʂ̐ݒ� ---
//==================================================================================
CParticleQuaternionBuilder &CParticleQuaternionBuilder::SetMove(const Vector3 &move)
{
	m_setting.move = move;
	return *this;
}

//==================================================================================
// --- �X�P�[���̐ݒ� ---
//==================================================================================
CParticleQuaternionBuilder &CParticleQuaternionBuilder::SetScale(const Vector2 &scale)
{
	m_setting.scale = scale;
	return *this;
}

//==================================================================================
// --- �F�̐ݒ� ---
//==================================================================================
CParticleQuaternionBuilder &CParticleQuaternionBuilder::SetColor(const Color &color)
{
	m_setting.color = color;
	return *this;
}

//==================================================================================
// --- 1�t���[��������̔������̐ݒ� ---
//==================================================================================
CParticleQuaternionBuilder &CParticleQuaternionBuilder::SetNumEffectFrame(const int nNumEffectFrame)
{
	m_setting.nNumEffectFrame = nNumEffectFrame;
	return *this;
}

//==================================================================================
// --- �������Ԃ̐ݒ� ---
//==================================================================================
CParticleQuaternionBuilder &CParticleQuaternionBuilder::SetLife(const int nLife)
{
	m_setting.nLife = nLife;
	return *this;
}

//==================================================================================
// --- �ʒu�̂Ԃ�̐ݒ� ---
//==================================================================================
CParticleQuaternionBuilder &CParticleQuaternionBuilder::SetPositionVariation(const Vector3 &posVariation)
{
	m_setting.posVariation = posVariation;
	return *this;
}

//==================================================================================
// --- �ړ��ʂ̂Ԃ�̐ݒ� ---
//==================================================================================
CParticleQuaternionBuilder &CParticleQuaternionBuilder::SetMoveVariation(const Vector3 &moveVariation)
{
	m_setting.moveVariation = moveVariation;
	return *this;
}

//==================================================================================
// --- �X�P�[���̂Ԃ�̐ݒ� ---
//==================================================================================
CParticleQuaternionBuilder &CParticleQuaternionBuilder::SetScaleVariation(const Vector2 &scaleVariation)
{
	m_setting.scaleVariation = scaleVariation;
	return *this;
}

//==================================================================================
// --- �������̂Ԃ�̐ݒ� ---
//==================================================================================
CParticleQuaternionBuilder &CParticleQuaternionBuilder::SetNumEffectVariation(const int nNumEffectVariation)
{
	m_setting.nNumEffectVariation = nNumEffectVariation;
	return *this;
}

//==================================================================================
// --- �����m���̐ݒ� ---
//==================================================================================
CParticleQuaternionBuilder &CParticleQuaternionBuilder::SetPercent(const int nPercent)
{
	m_setting.nPercent = nPercent;
	return *this;
}

//==================================================================================
// --- �G�t�F�N�g�̗̑͂̍ő�l�̐ݒ� ---
//==================================================================================
CParticleQuaternionBuilder &CParticleQuaternionBuilder::SetEffectLifeMax(const int nEffectLifeMax)
{
	m_setting.nEffectLifeMax = nEffectLifeMax;
	return *this;
}

//==================================================================================
// --- �G�t�F�N�g�̃��u�����f�B���O�̐ݒ� ---
//==================================================================================
CParticleQuaternionBuilder &CParticleQuaternionBuilder::SetEnableAlphaBlending(const bool bEnable)
{
	m_setting.bEnableAlphaBlending = bEnable;
	return *this;
}